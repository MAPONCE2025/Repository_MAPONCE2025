from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from datetime import datetime
from werkzeug.utils import secure_filename
import os
import uuid

# Configuración de la app
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///fallas.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = 'alguna_clave_segura'

# Carpeta para guardar fotos
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Configuración de validación de imágenes
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
MAX_CONTENT_LENGTH = 3 * 1024 * 1024  # 2 MB
app.config['MAX_CONTENT_LENGTH'] = MAX_CONTENT_LENGTH

# DB y migraciones
db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Función para validar extensión de archivo
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Modelos
class Falla(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    descripcion = db.Column(db.String(200), nullable=False)
    ubicacion = db.Column(db.String(100), nullable=False)
    fecha_reporte = db.Column(db.DateTime, default=datetime.utcnow)
    reportado_por = db.Column(db.String(100), nullable=False)
    estado = db.Column(db.String(20), default='pendiente')
    foto = db.Column(db.String(200))
    acciones = db.relationship('AccionReparacion', backref='falla', lazy=True)

class HistorialAccion(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    accion_id = db.Column(db.Integer, db.ForeignKey('accion_reparacion.id'), nullable=False)
    responsable = db.Column(db.String(100))
    fecha_planificada = db.Column(db.Date)
    fecha_real = db.Column(db.Date)
    acciones = db.Column(db.Text)
    materiales = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

class AccionReparacion(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    falla_id = db.Column(db.Integer, db.ForeignKey('falla.id'), nullable=False)
    responsable = db.Column(db.String(100), nullable=False)
    fecha_planificada = db.Column(db.Date, nullable=False)
    fecha_real = db.Column(db.Date, nullable=True)
    acciones = db.Column(db.Text)
    materiales = db.Column(db.Text)
    foto_reparacion = db.Column(db.String(200))  # Nuevo campo
    historial = db.relationship('HistorialAccion', backref='accion', lazy=True)

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Ruta principal
@app.route('/')
def index():
    fallas = Falla.query.order_by(Falla.fecha_reporte.desc()).all()
    return render_template('index.html', fallas=fallas)

# Ruta para reportar fallas con foto
from PIL import Image
from io import BytesIO
from datetime import datetime




# Ruta para gestionar una falla
@app.route('/gestionar/<int:id>', methods=['GET', 'POST'])
def gestionar(id):
    falla = Falla.query.get_or_404(id)

    if request.method == 'POST':
        fecha_planificada = datetime.strptime(request.form['fecha_planificada'], '%Y-%m-%d').date()
        fecha_real_str = request.form.get('fecha_real')
        fecha_real = datetime.strptime(fecha_real_str, '%Y-%m-%d').date() if fecha_real_str else None
        estado = request.form['estado']

        # ✅ Validación obligatoria si el estado es "resuelto" en backend
        if estado == "resuelto" and not fecha_real:
            flash("Debe ingresar la Fecha Real cuando el estado es 'Resuelto'.")
            return redirect(url_for('gestionar', id=id))

        # Procesar foto de reparación
        foto_reparacion = request.files.get('foto_reparacion')
        nombre_foto_reparacion = None
        if foto_reparacion and foto_reparacion.filename != '':
            if not allowed_file(foto_reparacion.filename):
                flash("Formato de imagen no permitido.")
                return redirect(url_for('gestionar', id=id))

            nombre_base = secure_filename(foto_reparacion.filename)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            nombre_seguro = f"{timestamp}_{nombre_base}"
            ruta_foto = os.path.join(app.config['UPLOAD_FOLDER'], nombre_seguro)

            try:
                img = Image.open(foto_reparacion)
                img_format = img.format
                img.thumbnail((800, 800))
                if img_format.lower() in ['jpeg', 'jpg']:
                    img.save(ruta_foto, format="JPEG", quality=80, optimize=True)
                elif img_format.lower() == 'png':
                    img.save(ruta_foto, format="PNG", optimize=True)
                else:
                    img.save(ruta_foto)
                nombre_foto_reparacion = nombre_seguro
            except Exception as e:
                flash(f"Error al procesar la foto de reparación: {e}")
                return redirect(url_for('gestionar', id=id))

        accion = AccionReparacion(
            falla_id=id,
            responsable=request.form['responsable'],
            fecha_planificada=fecha_planificada,
            fecha_real=fecha_real,
            acciones=request.form['acciones'],
            materiales=request.form['materiales'],
            foto_reparacion=nombre_foto_reparacion
        )

        falla.estado = estado
        db.session.add(accion)
        db.session.commit()
        flash("Acción registrada correctamente.")
        return redirect(url_for('index'))

    return render_template('gestionar.html', falla=falla)




# Manejo de errores de tamaño de archivo
@app.errorhandler(413)
def request_entity_too_large(error):
    flash("La imagen es demasiado grande. Máximo 2 MB.")
    return redirect(url_for('index'))

#if __name__ == '__main__':
#    app.run(debug=True)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Esto crea todas las tablas definidas en tus modelos
    app.run(debug=True)