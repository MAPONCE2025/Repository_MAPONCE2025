#!/bin/bash
python -c "from app import db; db.create_all()"
gunicorn app:app
