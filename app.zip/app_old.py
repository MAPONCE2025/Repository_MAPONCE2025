from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///fallas.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = 'alguna_clave_segura'

db = SQLAlchemy(app)

# Modelos de base de datos
class Falla(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    descripcion = db.Column(db.String(200), nullable=False)
    ubicacion = db.Column(db.String(100), nullable=False)
    fecha_reporte = db.Column(db.DateTime, default=datetime.utcnow)
    reportado_por = db.Column(db.String(100), nullable=False)
    estado = db.Column(db.String(20), default='pendiente')
    acciones = db.relationship('AccionReparacion', backref='falla', lazy=True)

class AccionReparacion(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    falla_id = db.Column(db.Integer, db.ForeignKey('falla.id'), nullable=False)
    responsable = db.Column(db.String(100), nullable=False)
    fecha_planificada = db.Column(db.Date, nullable=False)
    fecha_real = db.Column(db.Date, nullable=True)
    acciones = db.Column(db.Text)
    materiales = db.Column(db.Text)

# Asegurar carpeta templates
if not os.path.exists('templates'):
    os.makedirs('templates')

# ---------------- Plantillas ----------------

# index.html
with open('templates/index.html', 'w', encoding='utf-8') as f:
    f.write('''<!DOCTYPE html>
<html>
<head>
    <title>Fallas reportadas</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 2em; }
        input, textarea, select, button { margin: 0.5em 0; display: block; width: 100%; max-width: 400px; }
        ul { list-style: none; padding: 0; }
        li { margin-bottom: 1em; background: #f4f4f4; padding: 1em; border-radius: 5px; }
    </style>
</head>
<body>
    {% with messages = get_flashed_messages() %}
      {% if messages %}
        <ul style="color: green;">
          {% for message in messages %}
            <li>{{ message }}</li>
          {% endfor %}
        </ul>
      {% endif %}
    {% endwith %}

    <h1>Fallas reportadas</h1>
    <form action="/reportar" method="post">
        <input type="text" name="descripcion" placeholder="Descripción" required>
        <input type="text" name="ubicacion" placeholder="Ubicación" required>
        <input type="text" name="reportado_por" placeholder="Nombre del residente" required>
        <button type="submit">Reportar</button>
    </form>
    <ul>
        {% for falla in fallas %}
        <li>
            <strong>{{ falla.descripcion }}</strong> en {{ falla.ubicacion }}
            [{{ falla.estado }}] - <a href="/gestionar/{{ falla.id }}">Gestionar</a>
            <br><small>Reportado el {{ falla.fecha_reporte.strftime('%Y-%m-%d %H:%M') }} por {{ falla.reportado_por }}</small>
        </li>
        {% endfor %}
    </ul>
</body>
</html>''')

# gestionar.html
with open('templates/gestionar.html', 'w', encoding='utf-8') as f:
    f.write('''<!DOCTYPE html>
<html>
<head>
    <title>Gestionar Falla</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 2em; }
        input, textarea, select, button { margin: 0.5em 0; display: block; width: 100%; max-width: 400px; }
        .error { color: red; }
    </style>
    <script>
      function validarFormulario() {
        const planificada = new Date(document.querySelector('[name="fecha_planificada"]').value);
        const realInput = document.querySelector('[name="fecha_real"]');
        if (realInput.value) {
          const real = new Date(realInput.value);
          if (real < planificada) {
            alert("La fecha real no puede ser anterior a la fecha planificada.");
            return false;
          }
        }
        return true;
      }
    </script>
</head>
<body>
    <h1>Gestionar Falla</h1>
    <p><strong>Descripción:</strong> {{ falla.descripcion }}</p>
    <p><strong>Ubicación:</strong> {{ falla.ubicacion }}</p>

    <form method="post" onsubmit="return validarFormulario()">
        <input type="text" name="responsable" placeholder="Responsable" required>
        <input type="date" name="fecha_planificada" required>
        <input type="date" name="fecha_real">
        <textarea name="acciones" placeholder="Acciones realizadas"></textarea>
        <textarea name="materiales" placeholder="Materiales utilizados"></textarea>
        <select name="estado">
            <option value="pendiente" {% if falla.estado == 'pendiente' %}selected{% endif %}>Pendiente</option>
            <option value="en proceso" {% if falla.estado == 'en proceso' %}selected{% endif %}>En proceso</option>
            <option value="resuelto" {% if falla.estado == 'resuelto' %}selected{% endif %}>Resuelto</option>
        </select>
        <button type="submit">Guardar</button>
    </form>

    <h2>Historial de acciones</h2>
    <ul>
        {% for accion in falla.acciones %}
        <li>
            <strong>{{ accion.fecha_real.strftime('%Y-%m-%d') if accion.fecha_real else 'Fecha no registrada' }}</strong> –
            {{ accion.responsable }}: {{ accion.acciones or 'Sin acciones registradas' }}
            <br><em>Materiales:</em> {{ accion.materiales or 'Ninguno' }}
            <form action="/eliminar_accion/{{ accion.id }}" method="post" style="display:inline">
                <button type="submit" onclick="return confirm('¿Eliminar esta acción?')">Eliminar</button>
            </form>
        </li>
        {% else %}
        <li>No hay acciones registradas aún.</li>
        {% endfor %}
    </ul>

    <p><a href="/">Volver</a></p>
</body>
</html>''')

# ---------------- Rutas ----------------

@app.route('/')
def index():
    fallas = Falla.query.order_by(Falla.fecha_reporte.desc()).all()
    return render_template('index.html', fallas=fallas)

@app.route('/reportar', methods=['POST'])
def reportar():
    descripcion = request.form['descripcion']
    ubicacion = request.form['ubicacion']
    reportado_por = request.form['reportado_por']
    nueva_falla = Falla(descripcion=descripcion, ubicacion=ubicacion, reportado_por=reportado_por)
    db.session.add(nueva_falla)
    db.session.commit()
    flash("Falla reportada exitosamente.")
    return redirect(url_for('index'))

@app.route('/gestionar/<int:id>', methods=['GET', 'POST'])
def gestionar(id):
    falla = Falla.query.get_or_404(id)
    if request.method == 'POST':
        responsable = request.form['responsable']
        fecha_planificada = datetime.strptime(request.form['fecha_planificada'], '%Y-%m-%d').date()
        fecha_real_str = request.form.get('fecha_real')
        fecha_real = datetime.strptime(fecha_real_str, '%Y-%m-%d').date() if fecha_real_str else None
        acciones_texto = request.form['acciones']
        materiales_texto = request.form['materiales']
        estado = request.form['estado']

        nueva_accion = AccionReparacion(
            falla_id=id,
            responsable=responsable,
            fecha_planificada=fecha_planificada,
            fecha_real=fecha_real,
            acciones=acciones_texto,
            materiales=materiales_texto
        )
        falla.estado = estado
        db.session.add(nueva_accion)
        db.session.commit()
        flash("Acción guardada correctamente.")
        return redirect(url_for('gestionar', id=id))

    return render_template('gestionar.html', falla=falla)

@app.route('/eliminar_accion/<int:id>', methods=['POST'])
def eliminar_accion(id):
    accion = AccionReparacion.query.get_or_404(id)
    falla_id = accion.falla_id
    db.session.delete(accion)
    db.session.commit()
    flash("Acción eliminada.")
    return redirect(url_for('gestionar', id=falla_id))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
